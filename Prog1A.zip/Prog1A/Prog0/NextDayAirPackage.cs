﻿// Grading ID: C6221
// Program 1A
// Due: 9/25/2017 @ 11:59 pm
// CIS 200-01
// Description: This NextDayAirPackage class is a concrete derived class of AirPackage. This class adds an extra expense 
//              fee for next day air packages.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    class NextDayAirPackage : AirPackage
    {
        private decimal _expressFee; // backing field to hold the express fee

        // 7 parameter constructor
        // Precondition: Length >= 0, width >= 0, height >= 0, weight >= 0, express fee >= 0
        // Postcondition: The package is created with the specified values for origin address, destination address, 
        //                length, width, height, weight, and express fee
        public NextDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight, decimal expressFee)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            ExpressFee = expressFee;    // set express fee property
        }

        // name properties
        public decimal ExpressFee
        {
            // Precondition: none
            // Postcondition: express fee is returned
            get
            {
                return _expressFee;
            }
            // Precondition: none
            // Postcondition: Express fee is set to the specified value
            set
            {
                if (value >= 0)
                    _expressFee = value;
                else
                    throw new ArgumentOutOfRangeException("Express Fee", value,
                        "Express Fee must be >= 0");
            }
        }

        // Precondition: none
        // POstcondition: cost is returned
        public override decimal CalcCost()
        {
            const decimal DIM_COEFFICIENT = .40M;       // variable to hold the dimension factor
            const decimal WEIGHT_COEFFICIENT = .30M;    // variable to hold the weight factor
            const decimal HEAVY_COEFFICIENT = .25M;     // variable to hold the heavy factor
            const decimal LARGE_COEFFICIENT = .25M;     // variable to hold the large factor

            double TotalDimension = (Length + Width + Height);  // variable to hold the total dimension

            decimal NewCost; // variable to hold the cost

            NewCost = DIM_COEFFICIENT * (decimal)TotalDimension + WEIGHT_COEFFICIENT * (decimal)Weight + ExpressFee;

            if (IsHeavy())
            {
                NewCost += HEAVY_COEFFICIENT * (decimal)Weight;
            }

            if (IsLarge())
            {
                NewCost += LARGE_COEFFICIENT * (decimal)TotalDimension;
            }

            return NewCost;
        }

        // Precondition: none
        // Postcondition: string is returned
        public override String ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
                $"{DestinationAddress}{NL}Length: {Length:N1}{NL}" + $"Width: {Width:N1}{NL}"
                + $"Height: {Height:N1}{NL}" + $"Weight: {Weight:N1}{NL}" + $"Express Fee: {ExpressFee:C}{NL}"
                + $"CalcCost: {CalcCost():C}{NL}";
        }
    }
}
