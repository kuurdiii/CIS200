﻿// Grading ID: C6221
// Program 1A
// Due: 9/25/2017 @ 11:59 pm
// CIS 200-01
// Description: This AirPackage class is an abstract derived class of Package. This class adds two methods to determine if
//              if the package is heavy and/or large. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public abstract class AirPackage : Package
    {
        public const int HEAVY_MINIMUM = 75;    // constant variable of 75
        public const int LARGE_MINIMUM = 100;   // constant variable of 100


        // 6 parameter constructor
        // Precondition: Length >= 0, width >= 0, height >= 0, weight >= 0,
        // Postcondition: The package is created with the specified values for origin address, destination address, 
        //                length, width, height, and weight 
        public AirPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            // no body needed, all work done in base class constructor
        }

        // Precondition: none
        // Postcondition: returns true if air package is considered heavy, else returns false
        public bool IsHeavy()
        {
            return (Weight >= HEAVY_MINIMUM);
        }

        // Precondition: none
        // Postcondition: returns true if air package is considered large, else returns false
        public bool IsLarge()
        {
            double TotalDimension = (Length + Width + Height); // variable to hold the total dimension

            return (TotalDimension >= LARGE_MINIMUM);
        }

        // Precondition: none
        // Postcondition: string is returned
        public override String ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
                $"{DestinationAddress}{NL}Length: {Length:N1}{NL}" + $"Width: {Width:N1}{NL}"
                + $"Height: {Height:N1}{NL}" + $"Weight: {Weight:N1}{NL}" + $"IsHeavy: {IsHeavy()}{NL}"
                + $"IsLarge: {IsLarge()}{NL}";
        }


    }
}
