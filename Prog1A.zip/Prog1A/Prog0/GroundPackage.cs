﻿// Grading ID: C6221
// Program 1A
// Due: 9/25/2017 @ 11:59 pm
// CIS 200-01
// Description: This GroundPackage class is a concrete derived class of Package. This class calculates the cost based on 
//              the package dimenstions and weight, and the distance between the original 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class GroundPackage : Package
    {
        const int ZIP_CONVERSION_FACTOR = 10000;        // constant variable of 10000
        const double DIMENSION_FACTOR = .20;            // constant variable of .20
        const double WEIGHT_FACTOR = .05;               // constant variable of .05

        // 6 parameter constructor
        // Precondition: Length >= 0, width >= 0, height >= 0, weight >= 0,
        // Postcondition: The package is created with the specified values for origin address, destination address, 
        //                length, width, height, and weight 
        public GroundPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            // no body needed
        }

        // Precondition: none
        // Postcondition: The distance is returned with the specified value
        public int ZoneDistance()
        {
            int distance;

            distance = Math.Abs((OriginAddress.Zip / ZIP_CONVERSION_FACTOR - (DestinationAddress.Zip / ZIP_CONVERSION_FACTOR)));

            return distance;
        }

        // Precondition: none
        // Postcondition: The cost is returned 
        public override decimal CalcCost()
        {
            decimal NewCost;    // variable to hold the cost

            double TotalDimension = (Length + Width + Height); // variable to hold the total dimension 

            NewCost = (decimal)DIMENSION_FACTOR * (decimal)TotalDimension 
                + (decimal)WEIGHT_FACTOR * (ZoneDistance() + 1)*(decimal)Weight;

            return NewCost;
        }

        // Precondition: none
        // Postcondition: The string is returned
        public override String ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
                $"{DestinationAddress}{NL}Length: {Length:N1}{NL}" + $"Width: {Width:N1}{NL}"
                + $"Height: {Height:N1}{NL}" + $"Weight: {Weight:N1}{NL}" + $"Zone Distance: {ZoneDistance():N1}{NL}"
                + $"CalcCost: {CalcCost():C}{NL}";
        }
    }
}
