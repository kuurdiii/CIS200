﻿// Grading ID: C6221
// Program 1A
// Due: 9/25/2017 @ 11:59 pm
// CIS 200-01
// Description: This Package class is an abstract derived class of Parcel. This class tracks the dimensions (length, width
//              and height) and weight of each package.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public abstract class Package : Parcel
    {
        private double _length;     // backing field to hold the length
        private double _width;      // backing field to hold the width
        private double _height;     // backing field to hold the height
        private double _weight;     // backing field to hold the weight


        // 6 paramter constructor
        // Precondition: Length >= 0, width >= 0, height >= 0, weight >= 0
        // Postcondition: The package is created with the specified values for origin address, destination address, 
        //                length, width, height, and weight 
        public Package(Address originAddress, Address destAddress, double length, double width, double height, 
            double weight)
            : base(originAddress, destAddress)
        {
            Length = length;    // Set length property
            Width = width;      // Set width property
            Height = height;    // Set height property
            Weight = weight;    // Set weight property
        }

        // Name properties
        public double Length
        {
            // Precondition: None
            // Postcondition: Length is returned
            get
            {
                return _length;
            }
            // Precondition: None
            // Postcondition: Length has been set to the specified value
            set
            {
                if (value >= 0)
                    _length = value;
                else
                    throw new ArgumentOutOfRangeException("Length", value,
                        "Length must be >= 0");
            }
        }

        public double Width
        {
            // Precondition: None
            // Postcondition: Width is returned
            get
            {
                return _width;
            }
            // Precondition: None
            // Postcondition: Width has been set to the specified value
            set
            {
                if (value >= 0)
                    _width = value;
                else
                    throw new ArgumentOutOfRangeException("Width", value,
                        "Width must be >= 0");
            }
        }

        public double Height
        {
            // Precondition: None
            // Postcondition: Height is returned
            get
            {
                return _height;
            }
            // Precondition: None
            // Postcondition: Height has been set to the specified value
            set
            {
                if (value >= 0)
                    _height = value;
                else
                    throw new ArgumentOutOfRangeException("Height", value,
                        "Height must be >= 0");
            }
        }

        public double Weight
        {
            // Precondition: None
            // Postcondition: Weight is returned
            get
            {
                return _weight;
            }
            // Precondition: None
            // Postcondition: Weight has been set to the specified value
            set
            {
                if (value >= 0)
                    _weight = value;
                else
                    throw new ArgumentOutOfRangeException("Weight", value,
                        "Weight must be >= 0");
            }
        }

        // Precondition: none
        // Postcondition: A string with the package's data is returned
        public override String ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
                $"{DestinationAddress}{NL}Length: {Length:N1}{NL}" + $"Width: {Width:N1}{NL}" 
                + $"Height: {Height:N1}{NL}" + $"Weight: {Weight:N1}{NL}";
        }
    }
}
