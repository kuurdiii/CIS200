﻿// Grading ID: C6221
// Program 1A
// Due: 9/25/2017 @ 11:59 pm
// CIS 200-01
// Description: This TwoDayAirPackage class is a concrete derived class of AirPackage. This class specifies the time of day
//              packages are delivered. If morning delivery is requested the package is an "Early". If afternoon delivery
//              is requested, the package is a "Saver" and a discount will apply.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    class TwoDayAirPackage : AirPackage
    {
        public enum Delivery { Early, Saver };  // delivery types

        // 7 parameter constructor
        // precondition: length >= 0, width >= 0, height >= 0, weight >= 0, and delivery type is either early or saver
        // postcondition: 
        public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight, Delivery deliveryType)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            DeliveryType = deliveryType;    // set delivery type property
        }

        // Name property
        public Delivery DeliveryType
        {
            get; set; // delivery type is returned, delivery type is set to the specified value
        }

        // precondition: none
        // postcondition: cost is returned
        public override decimal CalcCost()
        {
            const decimal DIM_COEFF = .25M;             // dimension factor of .25
            const decimal WEIGHT_COEFF = .25M;          // weight factor of .25
            const decimal FINAL_COST_DISCOUNT = .90M;   // discount factor of .90

            double TotalDimension = (Length + Width + Height);  // variable to hold the total dimension

            decimal NewCost;    // variable to hold the cost

            NewCost = DIM_COEFF * (decimal)TotalDimension + WEIGHT_COEFF * (decimal)Weight;

            if (DeliveryType == Delivery.Saver)
            {
                NewCost *= FINAL_COST_DISCOUNT;
            }

            return NewCost;
        }

        // Precondition: none
        // Postcondition: string is returned
        public override String ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Origin Address:{NL}{OriginAddress}{NL}{NL}Destination Address:{NL}" +
                $"{DestinationAddress}{NL}Length: {Length:N1}{NL}" + $"Width: {Width:N1}{NL}"
                + $"Height: {Height:N1}{NL}" + $"Weight: {Weight:N1}{NL}" + $"Delivery Type: {DeliveryType}{NL}"
                + $"CalcCost: {CalcCost():C}{NL}";
        }
    }
}
